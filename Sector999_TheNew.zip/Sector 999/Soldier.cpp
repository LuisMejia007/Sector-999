//
//  Soldier.cpp
//  Sector 999
//
//  Created by Luis Mejia on 4/21/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#include "Soldier.h"

Soldier:: Soldier()
{
    x_coord = 0.0;
    y_coord = 0.0;
    soldierX_pos = x_coord;
    soldierY_pos = y_coord;
}

void Soldier:: draw(Master& m)
{
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 1.0f, 1.0f);
    
    //:: Top Edge
    glVertex2f(m.getX(), m.getY());
    glVertex2f(m.getX() + this->getWidth(), m.getY());
    
    //:: Left Edge
    glVertex2f(m.getX(), m.getY());
    glVertex2f(m.getX(), m.getY() - this->getHeight());
    
    //:: Right Edge
    glVertex2f(m.getX() + this -> getWidth(), m.getY());
    glVertex2f(m.getX() + this -> getWidth(), m.getY() - this -> getHeight());
    
    //:: Bottom Edge
    glVertex2f(m.getX() + this->getWidth(), m.getY() - this -> getHeight());
    glVertex2f(m.getX(), m.getY() - this -> getHeight());
    
    glEnd();
}


void Soldier:: setX(float x){ x_coord = x; }
void Soldier:: setY(float y){ y_coord = y; }
void Soldier:: setHeight(float h) { height = h; }
void Soldier:: setWidth(float w) { width = w; }

float Soldier:: getX(){ return x_coord; }
float Soldier:: getY(){ return y_coord; }
float Soldier:: getHeight() { return height;}
float Soldier:: getWidth() { return width; }

Soldier:: ~Soldier() { }
