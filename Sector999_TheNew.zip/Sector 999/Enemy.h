//
//  Enemy.hpp
//  Sector 999
//
//  Created by Luis Mejia on 4/25/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#ifndef Enemy_h
#define Enemy_h

#include <stdio.h>
# include "Shapes.h"
# include "Soldier.h"

class Enemy : public Shapes
{
    float health;
    float x_coord;
    float y_coord;
    float height;
    float width;
    float red, green, blue;
    
public:
    Enemy();
    Enemy(float _health, float x, float y, float w, float h, float r, float g, float b);
    void draw(Master& m);
    void draw();
    //:: Setters
    void setX( float x );
    void setY( float y );
    void setHeight( float h );
    void setWidth( float w );
    void setColors(float r, float g, float b);
    void setHealth(float h);
    
    //:: Getters
    float getX();
    float getY();
    float getHeight();
    float getWidth();
    float getRed();
    float getGreen();
    float getBlue();
    float getHealth(); 
    
    
    void health_damage(enum Soldier::Arsenal& weapon);
    bool contains(Master& m);
    
    ~Enemy();
    
    
};
#endif /* Enemy_h */
