//
//  Video_Game.h
//  Sector 999
//
//  Created by Luis Mejia on 4/21/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#ifndef Video_Game_h
#define Video_Game_h
# include <cmath>
# include <vector>
# include <queue> 
# include "GlutApp.h"
# include "Soldier.h"
# include "Shapes.h"
# include "Enemy.h"
# include "Functions.h"

using std:: vector;
using std:: queue;

class VDEO : public GlutApp
{
    float mx;   //:: Mouse Coord X
    float my;   //:: Mouse Coord Y
    
public:
    
    VDEO(const char* label, int x, int y, int w, int h);
    void draw(); 
    void keyPress(unsigned char key);
    void specialKeyPress(int key);
    void mouseDown(float x, float y);
    void mouseDrag(float x, float y);
    void idle();
    void initialize();
    //:: Multiple Class Objects will go here
//    Soldier soldier, enemy;
    Soldier soldier;
    Enemy enemy;
    
    Shapes bulletObj, _backBar, _healthBar;
    

    
    
    //:: Soldier Variables
    Soldier:: Movement soldier_mov;     //:: Enum for player movement (UP, DOWN, RIGHT, LEFT)
    Soldier:: Arsenal weapon;           //:: Enum for weapon selection
    float soldierX_pos = 0.0f;
    float soldierY_pos = 0.0f;
    
    
    //:: Enemy Variables
    float enemy_x, enemy_y;
    vector< Enemy*> enemies; 
    
    //:: Blasters

    vector<Shapes*> bullet_shapes;
    float bullet_x, bullet_y, bullet_speed;
    bool shooting; 
    void reload();
    int ammo;
    float moveX, moveY;
};

#endif /* Video_Game_h */
