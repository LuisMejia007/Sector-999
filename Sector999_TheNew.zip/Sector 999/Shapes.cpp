 //
//  Shapes.cpp
//  Sector 999
//
//  Created by Luis Mejia on 4/21/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#include "Shapes.h"



Shapes:: Shapes() {}

Shapes:: Shapes(float x, float y, float _h, float _w, float r, float g, float b)
: x_coord(x), y_coord(y), height(_h), width(_w), _r(r), _g(g), _b(b) {}

void Shapes:: draw(Master& m)
{
    glBegin(GL_POLYGON);
    
    glColor3f(getRed(), getGreen(), getBlue());
    
    //:: Top Edge
    glVertex2f(getX(), getY());
    glVertex2f(getX() + getWidth(), getY());
    
    //::Left Edge
    glVertex2f(getX(), getY());
    glVertex2f(getX(), getY() - getHeight());
    
    //:: Right Edge
    glVertex2f(getX() + getWidth(), getY());
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    //::Bottom Edge
    glVertex2f(getX(), getY() - getHeight());
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    glEnd(); 
    
}

void Shapes:: draw()
{
    glBegin(GL_POLYGON);
    
    glColor3f(getRed(), getGreen(), getBlue());
    
    //:: Top Edge
    glVertex2f(getX(), getY());
    glVertex2f(getX() + getWidth(), getY());
    
    //::Left Edge
    glVertex2f(getX(), getY());
    glVertex2f(getX(), getY() - getHeight());
    
    //:: Right Edge
    glVertex2f(getX() + getWidth(), getY());
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    //::Bottom Edge
    glVertex2f(getX(), getY() - getHeight());
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    glEnd();
    
}

//:: Setters
void Shapes:: setX( float x ){ x_coord = x; }

void Shapes:: setY( float y ){ y_coord = y; }

void Shapes:: setHeight( float h ) { height = h; }

void Shapes:: setWidth( float w ){ width = w; }

void Shapes:: setColors(float r, float g, float b) { _r = r; _g = g; _b = b; glColor3f(_r, _g, _b); }

//:: Getters
float Shapes:: getX() { return x_coord; }

float Shapes:: getY() { return y_coord; }

float Shapes:: getHeight() { return height; }

float Shapes:: getWidth() { return width; }

float Shapes:: getRed() { return _r; }
float Shapes:: getGreen() {return _g; }
float Shapes:: getBlue() {return _b; }


void Shapes:: move_bullet(Shapes *s, float bullet_speed)
{
    //:: If Soldier is moving left, decrement through the x coord by the bullet's speed
    if (s->left) { s->setX(s->getX() - bullet_speed); }
    
    //:: If Soldier is moving right, increment through the x coord by the bullet's speed
    if(s->right) { s->setX(s->getX() + bullet_speed); }
    
    //:: If Soldier is moving up, increment through the y coord by the bullet's speed
    if (s->up) { s->setY(s->getY() + bullet_speed); }
    
    //:: If Soldier is moving down, decrement through the y coord by the bullet's speed
    if (s->down) { s->setY(s->getY() - bullet_speed); }
}

void Shapes:: moveTheBullet(Shapes *s, float bullet_speed, Master& _soldier)
{
    
    
    float delta_y = s -> trajectoryY - _soldier.getY();
    float delta_x = s -> trajectoryX - _soldier.getX();
    float angle = std::atan2f(delta_y, delta_x);

    s -> setY(s -> getY() + std::sin(angle) * bullet_speed);
    s -> setX( s -> getX() + std::cos(angle) * bullet_speed);



}


bool Shapes:: contains(Master &m)
{
    if(m.getX() >= this->getX() && m.getX() <= (this->getX() + this->getWidth()))
    {
        if(m.getY() <= this->getY() && m.getY() >= (this->getY() - this->getHeight()))
        {
            puts("Inside");
            return true;
        }
        
    }
    return false;
}



Shapes:: ~Shapes() {} ;