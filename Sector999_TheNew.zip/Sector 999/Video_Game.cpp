# include "Video_Game.h"

VDEO::VDEO(const char* label, int x, int y, int w, int h): GlutApp(label, x, y, w, h){
    // Initialize state variables
    mx = 0.0;
    my = 0.0;
    shooting = false;
    VDEO::initialize();
    
}

void VDEO:: draw()
{
    // Clear the screen
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    // Set background color to black
    glClearColor(0.0, 0.0, 0.0, 1.0);
    
    // Set up the transformations stack
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
  
    glColor3d(1.0, 1.0, 0.0);
    
    for (vector<Shapes*>::iterator i = bullet_shapes.begin(); i != bullet_shapes.end(); i++)
    {
        if((*i)->_draw)
        {
            (*i)->draw();
        }
        
    }
    
    for(vector<Enemy* >::iterator i = enemies.begin(); i != enemies.end(); i++)
    {
        (*i)->draw();
    }
    

    
    soldier.setX(soldier.getX());
    soldier.setY(soldier.getY());
    soldier.draw(soldier);
    enemy.draw(enemy);
    
        glBegin(GL_LINES);
    
    glVertex2f(mx - 0.05f, my);
    glVertex2f(mx + 0.05f, my);
    
    glVertex2f(mx, my - 0.05f);
    glVertex2f(mx, my + 0.05f);
    
    glEnd();
    if (shooting == true)
    {
        std::cout << "About To Draw: " << ammo << "\n";

    }
    
    glFlush();
    glutSwapBuffers();
}

void VDEO:: keyPress(unsigned char key)
{
    switch(key)
    {
        case 27:
        exit(0);
        break;
            
        case 49:    //:: Case 49 is keypad number 1
              ammo = 25;
           weapon = Soldier::PISTOL;
            redraw();
            break;
            
        case 50:    //:: Case 50 is keypad number 2
            ammo = 99;
            weapon = Soldier::ASSAULT_RIFLE;
            redraw();
            break;
            
        case 51:     //:: Case 51 is keypad number 3
            ammo = 50;
            weapon = Soldier:: MINI_GUN;
            redraw();
            break;
            
        case 'r':
            reload();
            break;
            
            
    }
}

void VDEO:: specialKeyPress(int key)
{
    switch(key)
    {
        case GLUT_KEY_UP:
            soldierY_pos += 0.05f;
            soldier_mov = Soldier:: UP;
            soldier.setY(soldierY_pos);
            redraw();
            break;
            
        case GLUT_KEY_DOWN:
            soldier_mov = Soldier:: DOWN;
            soldierY_pos -= 0.05f;
            soldier.setY(soldierY_pos);
            redraw();
            break;
            
        case GLUT_KEY_RIGHT:
            soldier_mov = Soldier:: RIGHT;
            soldierX_pos += 0.05f;
            soldier.setX(soldierX_pos);
            redraw();
            break;
            
        case GLUT_KEY_LEFT:
            soldier_mov = Soldier:: LEFT;
            soldierX_pos -= 0.05f;
            soldier.setX(soldierX_pos);
            redraw();
            break;
    }
}



void VDEO:: mouseDown(float x, float y){
    
    mx = x; my = y;
    if( ammo == 0 ) { shooting = false; }
    else
    {
        //:: Create a new "bullet" which is just a pointer to the Shapes class
        //:: By Default it will have the X and Y position of the soldier
        shooting = true;
        Shapes* bullet = new Shapes();
        bullet -> setX(soldier.getX());
        bullet -> setY(soldier.getY());
        switch (weapon) {
            case Soldier::PISTOL:
                bullet -> setColors(1.0, 1.0, 1.0);
                bullet -> setWidth(0.04f);
                bullet -> setHeight(0.04f);
                break;
                
            case Soldier::ASSAULT_RIFLE:
                bullet -> setColors(1.0f, 1.0f, 0.0f);
                bullet -> setWidth(0.03f);
                bullet -> setHeight(0.03f);
                break;
            case Soldier:: MINI_GUN:
                bullet -> setColors(0.0f, 0.5f, 1.0f);
                bullet -> setWidth(0.02f);
                bullet -> setHeight(0.03f);
                break;
            default:
                break;
        }
        //Shapes* bullet = new Shapes (soldier.getX(), soldier.getY(), 0.04, 0.04, 1.0, 0.0, 0.0);
        bullet -> trajectoryX = mx;
        bullet -> trajectoryY = my;
        bullet_shapes.push_back(bullet);
        ammo--;
    }
    
    redraw();

}
void VDEO:: mouseDrag(float x, float y){shooting = true; mx = x; my = y; redraw(); }



void VDEO:: idle()
{
    //:: check_shooting
    if(ammo == 0)
    {
        puts("Ran out of bullets, can not shoot");
        shooting = false;
    }

    if(shooting)
    {
        switch(weapon)
        {   case Soldier::PISTOL:   bullet_speed = 0.02f; break;
            case Soldier::ASSAULT_RIFLE: bullet_speed = 0.03f; break;
            case Soldier::MINI_GUN: bullet_speed = 0.05f; break;
        }
    }
    
    for (vector<Shapes*>::iterator i = bullet_shapes.begin(); i != bullet_shapes.end(); i++)
    {
        //:: Continuosly moving the bullets that have been shot. Check Shapes.h for more details on the 'move_bullet' function
        //bulletObj.move_bullet((*i), bullet_speed);
      bulletObj.moveTheBullet((*i), bullet_speed, soldier);
      //::Check if Bullet Hit Enemy
        if( enemy.contains(*(*i)))
       {
           enemy.health_damage(weapon);
       }
        
        if ((*i)->getY() > 1.0 || (*i)->getY() < -1.0 || (*i)->getX() > 1.0 || (*i)->getX() < -1.0)
        {
            delete *i;
            bullet_shapes.erase(i);
            if(i == bullet_shapes.end())
            {
                break;
            }
        }
        
        
 
        
        for(vector<Enemy* >:: iterator j = enemies.begin(); j != enemies.end(); j++)
        {
            if((*j)->contains(*(*i)))
            {
                (*i) -> _draw = false;  //:: When Bullet hits enemy do not draw the bullet
               
                if((*j)->getHealth() <= 0.0f)
                {
                    delete (*j);
                    enemies.erase(j);
                    if(j == enemies.end()) {break;}
                }
                (*j)->health_damage(weapon);
            }
            
        }
    }
    
    
    for(vector<Enemy* >::iterator x = enemies.begin(); x!= enemies.end(); x++)
    {
        float d = std::sqrt( std::pow((soldier.getX() - (*x)->getX()), 2) - std::pow((soldier.getY() - (*x)->getY()), 2));
        
        if(soldier.getX() != (*x)->getX())
        {
         
            float m = -1 *((soldier.getY() - (*x)->getY()) / (soldier.getX() - (*x)->getX()));
            float x_1;
            float y;
            
            if((*x)->getX() < soldier.getX())
            {
                x_1 = (*x)->getX() + 0.001f; //CAN ADJUST SPEED
 
                
                //AVOID JITTERING
                if(x_1 > soldier.getX())
                    x_1 = soldier.getX();
                
            }
            else if ((*x)->getX() > soldier.getX())
            {
                x_1 = (*x)->getX() - 0.001f; //CAN ADJUST SPEED
                
                
                //AVOID JITTERING
                if(x_1 < soldier.getX())
                    x_1 = soldier.getX();
            }
            
            //FORMULATE Y
            y = m * ((*x)->getX() - x_1) + (*x)->getY();
            
            //UPDATE COORDINATES
            (*x)->setX(x_1);
            (*x)->setY(y);
            
        }
        else
        {
            if((*x)->getY() < soldier.getY())
                //(*x)->setY((*x)->getY() + 0.00001); //CAN ADJUST SPEED
            
                (*x)->setY( ((*x)->getY() + 0.00001) * 0.001) ; //CAN ADJUST SPEED
            
            else if((*x)->getY() > soldier.getY())
                //(*x)->setY((*x)->getY() - 0.00001);
                (*x)->setY( ((*x)->getY() - 0.00001) * 0.001);

            
            
        }
    }
    

    redraw();
}

void VDEO:: reload()
{

    if(ammo == 0)
    {
        switch(weapon)
        {
            case Soldier::PISTOL:
                ammo = 25;
                break;
            case Soldier:: ASSAULT_RIFLE:
                ammo = 99;
                break;
            case Soldier:: MINI_GUN:
                ammo = 50;
                break;
        }
    }
    
}

void VDEO:: initialize()
{
  //:: Soldier Initialization
    weapon = Soldier::ASSAULT_RIFLE;
    ammo = 99;
    soldier.setY(soldierY_pos);
    soldier.setX(soldierX_pos);
    soldier.setWidth(0.2f);
    soldier.setHeight(0.2f);
    soldier.draw(soldier);
    
    //        Enemy(float _health, float x, float y, float w, float h, float r, float g, float b);

    
    Enemy* enemy1 = new Enemy(50.0f, 0.7f, 0.7f,0.1f, 0.1f, 0.0f, 0.5f, 1.0f);
    Enemy* enemy2 = new Enemy(50.0f, -0.7f, -0.7f, 0.1f, 0.1f, 0.0f, 1.0f, 0.0f);
    Enemy* enemy3 = new Enemy (100.0f, 0.2f, 0.2f, 0.1f, 0.1f, 1.0f, 0.0f, 0.0f);
    Enemy* enemy4 = new Enemy (100.0f, -0.2f, -0.2f,0.1f, 0.1f, 0.5, 0.0, 0.8f);
    
    enemies.push_back(enemy1);
    enemies.push_back(enemy2);
    enemies.push_back(enemy3);
    enemies.push_back(enemy4);
    
    
    enemy.setX(0.7f);
    enemy.setY(0.7f);
    enemy.setWidth(0.3f);
    enemy.setHeight(0.2f);
    enemy.setColors(0.0, 0.0, 1.0);
    enemy.draw(enemy);
}