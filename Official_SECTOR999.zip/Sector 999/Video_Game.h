//
//  Video_Game.h
//  Sector 999
//
//  Created by Luis Mejia on 4/21/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#ifndef Video_Game_h
#define Video_Game_h
# include <cmath>
# include <ctime>
# include <chrono>
# include <vector>
# include <queue> 
# include "GlutApp.h"
# include "RgbImage.h"
# include "Soldier.h"
# include "Shapes.h"
# include "Enemy.h"
# include "Functions.h"
# include "SpawningLocations.h"

using std:: vector;

//:: Time Parameters
using std:: time;
using std:: time_t;
using std::chrono:: nanoseconds;
using std::chrono:: seconds;
using std::chrono:: minutes;
using std::chrono:: hours;


//:: String Parameters
using std:: string;
using std:: to_string;

class VDEO : public GlutApp
{
    float mx;   //:: Mouse Coord X
    float my;   //:: Mouse Coord Y
    //KEEP TRACK OF SPAWNING LOCATION.......................
    SpawningLocation locations[8];
    bool game_over = false;
    bool start_game = false;
    
public:
    
    VDEO(const char* label, int x, int y, int w, int h);
    void draw(); 
    void keyPress(unsigned char key);
    void specialKeyPress(int key);
    void mouseDown(float x, float y);
    void mouseDrag(float x, float y);
    void idle();
    void initialize();
    void start_game_menu();
    void game_over_menu(); 
    
    //:: Time Utilities
    time_t start_time, current_time;
    nanoseconds ns;
    seconds seconds;
    minutes minutes;
    hours hours;
    void updateTime(::nanoseconds& nano, ::seconds& sec, ::minutes& min, ::hours& hrs);
    void display_time();
    //TIME VARIABLES USED TO SPAWN A NEW ENEMY EVERY 5 SECS.
    time_t startTime, endTime;
    double timeDifference;
    
    
    //:: Textures
    GLuint loadTexture(const char* filename);
    GLuint alien;
    GLuint galaxy;
    GLuint sector;
    GLuint opposing;
    GLuint p1;
    GLuint sector_logo;
    GLuint sector_999;
    GLuint sector_invert;
    GLuint shrek;
  

    
    //:: Multiple Class Objects will go here
    Soldier soldier;
    Enemy enemy;
    Shapes bulletObj, _backBar, _healthBar;


    //:: Soldier Utilities
    Shapes* health_bar = new Shapes(-0.98f, -0.92f, 0.02f, 1.0f, 0.0f, 1.0f, 0.0f);
    Soldier:: Movement soldier_mov;     //:: Enum for player movement (UP, DOWN, RIGHT, LEFT)
    Soldier:: Arsenal weapon;           //:: Enum for weapon selection
    float soldierX_pos = 0.0f;
    float soldierY_pos = 0.0f;
    float red;
    void player_health_update(); 
    
    
    //:: Enemy Utilities
    float enemy_x, enemy_y;
    Enemy enemy_controller;
    vector< Enemy*> enemies;
    int enemy_killed_counter = 0;
    void enemy_initialize(Enemy *&enemy);
    void initializeSpawningLocations(SpawningLocation (&locations)[8]);
    void death_score();
    bool init_shrek = false;
    
    //:: Blaster Utilities
    string selected_weapon;
    vector<Shapes*> bullet_shapes;
    float bullet_x, bullet_y, bullet_speed;
    bool shooting; 
    void reload();
    void check_gun_type();
    int ammo;
    float moveX, moveY;
    void bullet_update();
    void display_gun();
    void ammo_display();

    
    //:: Power Ups
    vector<Shapes* > power_ups;
    

};

#endif /* Video_Game_h */
