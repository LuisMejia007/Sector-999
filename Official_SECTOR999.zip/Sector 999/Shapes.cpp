 //
//  Shapes.cpp
//  Sector 999
//
//  Created by Luis Mejia on 4/21/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#include "Shapes.h"



Shapes:: Shapes() {}

Shapes:: Shapes(float x, float y, float _h, float _w, float r, float g, float b)
: x_coord(x), y_coord(y), height(_h), width(_w), _r(r), _g(g), _b(b) {}

void Shapes:: draw(Master& m)
{
    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    
    glBegin(GL_QUADS);
    glBegin(GL_POLYGON);
    
    
    glColor3f(getRed(), getGreen(), getBlue());
    
    //:: Top Edge
     glTexCoord2f(0.0, 0.0);
    glVertex2f(getX(), getY());
    glVertex2f(getX() + getWidth(), getY());
    
    //::Left Edge
        glTexCoord2f(0.0, 1.0);
    glVertex2f(getX(), getY());
    glVertex2f(getX(), getY() - getHeight());
    
    //:: Right Edge
      glTexCoord2f(1.0, 1.0);
    glVertex2f(getX() + getWidth(), getY());
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    //::Bottom Edge
      glTexCoord2f(1.0, 0.0);
    glVertex2f(getX(), getY() - getHeight());
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    glEnd();
    glDisable(GL_TEXTURE_2D);
    
}

void Shapes:: draw()
{
    glEnable(GL_TEXTURE_2D); //M.R
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); //M.R
    glBegin(GL_POLYGON);
    
    glColor3f(getRed(), getGreen(), getBlue());
    
    //:: Top Edge
    glVertex2f(getX(), getY());
    glVertex2f(getX() + getWidth(), getY());
    
    //::Left Edge
    glVertex2f(getX(), getY());
    glVertex2f(getX(), getY() - getHeight());
    
    //:: Right Edge
    glVertex2f(getX() + getWidth(), getY());
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    //::Bottom Edge
    glVertex2f(getX(), getY() - getHeight());
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    glEnd();
    glDisable(GL_TEXTURE_2D);
    
}

//:: Setters
void Shapes:: setX( float x ){ x_coord = x; }

void Shapes:: setY( float y ){ y_coord = y; }

void Shapes:: setHeight( float h ) { height = h; }

void Shapes:: setWidth( float w ){ width = w; }

void Shapes:: setColors(float r, float g, float b) { _r = r; _g = g; _b = b; glColor3f(_r, _g, _b); }

//:: Getters
float Shapes:: getX() { return x_coord; }

float Shapes:: getY() { return y_coord; }

float Shapes:: getHeight() { return height; }

float Shapes:: getWidth() { return width; }


float Shapes:: getRed() { return _r; }
float Shapes:: getGreen() {return _g; }
float Shapes:: getBlue() {return _b; }




void Shapes:: moveTheBullet(Shapes *s, float bullet_speed, Soldier& _soldier)
{
    
//    
//    float delta_y = s -> trajectoryY - _soldier.getY();
//    float delta_x = s -> trajectoryX - _soldier.getX();
    
    float delta_y = s -> trajectoryY - _soldier.getCenterY();
    float delta_x = s -> trajectoryX - _soldier.getCenterX();

    float angle = std::atan2f(delta_y, delta_x);

    s -> setY(s -> getY() + std::sin(angle) * bullet_speed);
    s -> setX( s -> getX() + std::cos(angle) * bullet_speed);



}


bool Shapes:: contains(Master &m)
{
    if(m.getX() >= this->getX() && m.getX() <= (this->getX() + this->getWidth()))
    {
        if(m.getY() <= this->getY() && m.getY() >= (this->getY() - this->getHeight()))
        {
            return true;
        }
        
    }
    return false;
}



Shapes:: ~Shapes() {} ;