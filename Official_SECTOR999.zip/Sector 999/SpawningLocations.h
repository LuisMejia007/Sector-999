//
//  SpawningLocation.h
//  glutapp
//
//  Created by Sergio Rosendo on 5/1/17.
//  Copyright © 2017 Angelo Kyrilov. All rights reserved.
//

#ifndef SpawningLocation_h
#define SpawningLocation_h

class SpawningLocation
{
private:
    //LOCATION..................
    float x_coordinate;
    float y_coordinate;
    
public:
    //CONSTRUCTOR...............
    SpawningLocation();
    
    //SETTERS...................
    void setX(float);
    void setY(float);
    
    //GETTERS...................
    float getX();
    float getY();
    
    
    
    
};

#endif /* SpawningLocation_h */
