//
//  Shapes.hpp
//  Sector 999
//
//  Created by Luis Mejia on 4/21/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#ifndef Shapes_h
#define Shapes_h

# include <stdio.h>
# include <cmath>
# include "Master.h"



class Shapes : public Master
{
    float x_coord;
    float y_coord;
    float _r;
    float _g;
    float _b;
    float width;
    float height;
    
    float m, y_inc; 
    
    
public:
  
    Shapes();
    Shapes(float x, float y, float _h, float _w, float r, float g, float b);
    
    //:: These Boolean Variables will be used for bullet trajectory
    bool left = false;
    bool right = false;
    bool up = false;
    bool down = false;
    bool _draw = true;

    
    void draw(Master& m);
    void draw(); 
    //:: Setters
    void setX( float x );
    void setY( float y );
    void setHeight( float h );
    void setWidth( float w );
    void setColors(float r, float g, float b);
    
    //:: Getters
    float getX();
    float getY();
    float getHeight();
    float getWidth();
    float getRed();
    float getGreen();
    float getBlue();
    
    float trajectoryX, trajectoryY; 
    void moveTheBullet(Shapes* s, float bullet_speed, Master& _soldier);
    //:: @param : A pointer to shapes (will be used to set trajectory) and bullet's speed (will be based on soldier's weapon type)
    
    bool contains(Master&m);

    
    ~Shapes(); 
    
};
#endif /* Shapes_hpp */
