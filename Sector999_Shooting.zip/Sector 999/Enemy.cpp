//
//  Enemy.cpp
//  Sector 999
//
//  Created by Luis Mejia on 4/25/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#include "Enemy.h"

Enemy:: Enemy()
{
    health = 100.0f;
}

Enemy:: Enemy(float _health, float x, float y, float w, float h, float r, float g, float b)
    :health(_health), x_coord(x), y_coord(y), width(w), height(h),red(r), green(g), blue(b) {}

void Enemy:: draw(Master& m)
{
    glBegin(GL_POLYGON);
    
    glColor3f(getRed(), getGreen(), getBlue());
    
    //:: Top Edge
    glVertex2f(getX(), getY());
    glVertex2f(getX() + getWidth(), getY());
    
    //::Left Edge
    glVertex2f(getX(), getY());
    glVertex2f(getX(), getY() - getHeight());
    
    //:: Right Edge
    glVertex2f(getX() + getWidth(), getY());
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    //::Bottom Edge
    glVertex2f(getX(), getY() - getHeight());
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    glEnd();
    
}

void Enemy:: draw()
{
    glBegin(GL_POLYGON);
    
    glColor3f(getRed(), getGreen(), getBlue());
    
    //:: Top Edge
    glVertex2f(getX(), getY());
    glVertex2f(getX() + getWidth(), getY());
    
    //::Left Edge
    glVertex2f(getX(), getY());
    glVertex2f(getX(), getY() - getHeight());
    
    //:: Right Edge
    glVertex2f(getX() + getWidth(), getY());
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    //::Bottom Edge
    glVertex2f(getX(), getY() - getHeight());
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    glEnd();
    
}

//:: Setters
void Enemy:: setX( float x ){ x_coord = x; }

void Enemy:: setY( float y ){ y_coord = y; }

void Enemy:: setHeight( float h ) { height = h; }

void Enemy:: setWidth( float w ){ width = w; }

void Enemy:: setColors(float r, float g, float b) {red = r; green= g; blue = b; glColor3f(red, green, blue); }

void Enemy:: setHealth(float h) { health = h; }

//:: Getters
float Enemy:: getX() { return x_coord; }

float Enemy:: getY() { return y_coord; }

float Enemy:: getHeight() { return height; }

float Enemy:: getWidth() { return width; }

float Enemy:: getRed() { return red; }
float Enemy:: getGreen() {return green; }
float Enemy:: getBlue() {return blue; }

float Enemy:: getHealth(){ return health; }



void Enemy:: health_damage(enum Soldier::Arsenal& gun)
{
    switch (gun) {
        case Soldier::PISTOL:
            health -= 0.25;
            puts("Pistol");
            break;
            
        case Soldier::ASSAULT_RIFLE:
            health -= 0.50;
            puts("AR");
            break;
        case Soldier::MINI_GUN:
            health -= .75;
            puts("Mini Gun");
            
        default:
            break;
    }
    
    if(this->getHealth() <= 0.0f)
    {
        puts("Enemy has died");
    }
    
    else
    {
        printf("Enemy Health: %f \n", this->getHealth());
    }
}

bool Enemy:: contains(Master& m)
{
    if(m.getX() >= this->getX() && m.getX() <= (this->getX() + this->getWidth()))
    {
        if(m.getY() <= this->getY() && m.getY() >= (this->getY() - this->getHeight()))
        {
            puts("Enemy Shot");
            return true;
        }
        
    }
    return false;
}


Enemy:: ~Enemy() {}

