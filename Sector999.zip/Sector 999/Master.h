//
//  Master.h
//  Sector 999
//
//  Created by Luis Mejia on 4/21/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#ifndef Master_h
#define Master_h
#include <vector>         //:: Incase we need vectors
#include <cstdlib>        //:: Rand Functionality
# include "GlutApp.h"  //:: Video Game Functionality
class Master{
    
    float x_coord;
    float y_coord;
    
public:
    virtual void draw(Master& m) = 0;
    virtual float getX() = 0;
    virtual float getY() = 0;
    virtual void setX(float x) = 0;
    virtual void setY(float y) = 0;
    
    
    
};
#endif /* Master_h */
