# include "Video_Game.h"

VDEO::VDEO(const char* label, int x, int y, int w, int h): GlutApp(label, x, y, w, h){
    // Initialize state variables
    mx = 0.0;
    my = 0.0;
    shooting = false;
    VDEO::initialize();
    
}

void VDEO:: draw()
{
    // Clear the screen
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    // Set background color to black
    glClearColor(0.0, 0.0, 0.0, 1.0);
    
    // Set up the transformations stack
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
  
    glColor3d(1.0, 1.0, 0.0);
    
    for (vector<Shapes*>::iterator i = bullet_shapes.begin(); i != bullet_shapes.end(); i++)
    {
        (*i)->draw();
    }
    
    for(vector<Enemy* >::iterator i = enemies.begin(); i != enemies.end(); i++)
    {
        (*i)->draw();
    }
    
    glBegin(GL_LINES);
    
    glVertex2f(mx - 0.05f, my);
    glVertex2f(mx + 0.05f, my);
    
    glVertex2f(mx, my - 0.05f);
    glVertex2f(mx, my + 0.05f);
    
    glEnd();
    
    
    soldier.setX(soldier.getX());
    soldier.setY(soldier.getY());
    soldier.draw(soldier);
    enemy.draw(enemy);
    
    
    if (shooting == true)
    {
        //std::cout << "About To Draw: " << ammo << "\n";

    }
    
    glFlush();
    glutSwapBuffers();
}

void VDEO:: keyPress(unsigned char key)
{
    switch(key)
    {
        case 27:
        exit(0);
        break;
            
        case 49:    //:: Case 49 is keypad number 1
           weapon = Soldier::PISTOL;
            redraw();
            break;
            
        case 50:    //:: Case 50 is keypad number 2
            weapon = Soldier::ASSAULT_RIFLE;
            redraw();
            break;
            
        case 51:     //:: Case 51 is keypad number 3
            weapon = Soldier:: MINI_GUN;
            redraw();
            break;
            
        case 32:     //:: Case 32 is spacebar
            
            if( ammo == 0 ) { shooting = false; }
            else
            {
                shooting = true;
                //:: Create a new "bullet" which is just a pointer to the Shapes class
                //:: By Default it will have the X and Y position of the soldier
                Shapes* bullet = new Shapes (soldier.getX(), soldier.getY(), 0.04, 0.04, 1.0, 0.0, 0.0);
                switch (soldier_mov)
                {
                    //:: If the soldier moved up, set this bullet's lifetime trajectory going up
                    case Soldier::UP:
                        bullet -> up = true;
                        bullet_shapes.push_back(bullet);
                        break;
                    
                    //:: If the soldier moved right, set this bullet's lifetime trajectory going right
                    case Soldier:: RIGHT:
                        bullet->right = true;
                        bullet_shapes.push_back(bullet);
                        break;
                    //:: If the soldier moved down, set this bullet's lifetime trajectory going down
                    case Soldier:: DOWN:
                        bullet->down = true;
                        bullet_shapes.push_back(bullet);
                        break;
                    //:: If the soldier moved left, set this bullet's lifetime trajectory going left
                    case Soldier:: LEFT:
                        bullet->left = true;
                        bullet_shapes.push_back(bullet);
                        break;
                        
                    default:
                        break;
                }
                ammo--;
               // std::cout << "Bullets: " << ammo << "\n";
            }
            redraw();
            break;
            
        case 'r':
            reload();
            break;
            
            
    }
}

void VDEO:: specialKeyPress(int key)
{
    switch(key)
    {
        case GLUT_KEY_UP:
            my += 0.03f;
            shooting = false;
            soldier_mov = Soldier:: UP;
            soldier.setY(my);
            redraw();
            break;
            
        case GLUT_KEY_DOWN:
            shooting = false;
            soldier_mov = Soldier:: DOWN;
            my -= 0.03f;
            soldier.setY(my);
            redraw();
            break;
            
        case GLUT_KEY_RIGHT:
            shooting = false;
            soldier_mov = Soldier:: RIGHT;
             mx += 0.03f;
            soldier.setX(mx);
            redraw();
            break;
            
        case GLUT_KEY_LEFT:
            shooting = false;
            soldier_mov = Soldier:: LEFT;
            mx -= 0.03f;
            soldier.setX(mx);
            redraw();
            break;
    }
}



void VDEO:: mouseDown(float x, float y){}
void VDEO:: mouseDrag(float x, float y){}



void VDEO:: idle()
{
    // Go through bullet_shapes again and remove from the list any bullets whose y value is out of screen
    if(ammo == 0)
    {
        puts("Ran out of bullets, can not shoot");
        shooting = false;
    }
    
    if(shooting)
    {
        switch(weapon)
        {   case Soldier::PISTOL:   bullet_speed = 0.02f; break;
            case Soldier::ASSAULT_RIFLE: bullet_speed = 0.03f; break;
            case Soldier::MINI_GUN: bullet_speed = 0.05f; break;
        }
    }
    
    for (vector<Shapes*>::iterator i = bullet_shapes.begin(); i != bullet_shapes.end(); i++)
    {
        //:: Continuosly moving the bullets that have been shot. Check Shapes.h for more details on the 'move_bullet' function
        bulletObj.move_bullet((*i), bullet_speed);
        
      //::Check if Bullet Hit Enemy
        if( enemy.contains(*(*i)))
       {
           enemy.health_damage(weapon);
       }
        
        //std::cout << "Bullet Shape Size: " << bullet_shapes.size() << "\n";
        
        if ((*i)->getY() > 1.0)
        {
            delete *i;
            bullet_shapes.erase(i);
            if(i == bullet_shapes.end())
            {
                break;
            }
        }
        
        for(vector<Enemy* >:: iterator j = enemies.begin(); j != enemies.end(); j++)
        {
            if((*j)->contains(*(*i)))
            {
                if((*j)->getHealth() <= 0.0f)
                {
                    delete (*j);
                    enemies.erase(j);
                    if(j == enemies.end()) {break;}
                }
                (*j)->health_damage(weapon);
            }
        }
    }
    
//enemy.contains(soldier);
    redraw();
}

void VDEO:: reload()
{

    if(ammo == 0)
    {
        switch(weapon)
        {
            case Soldier::PISTOL:
                ammo = 25;
                break;
            case Soldier:: ASSAULT_RIFLE:
                ammo = 99;
                break;
            case Soldier:: MINI_GUN:
                ammo = 50;
                break;
        }
       // ammo = 10;
        //std::cout << "Bullets After Reload: " << ammo << "\n";
    }
    
}

void VDEO:: initialize()
{
  //:: Soldier Initialization
    weapon = Soldier::ASSAULT_RIFLE;
    ammo = 99;
    
    soldier.setY(0.0f);
    soldier.setX(0.1f);
    soldier.draw(soldier);
    
    
    Enemy* enemy1 = new Enemy(100.0f, 0.7f, 0.7f,0.3f, 0.2f, 1.0f, 0.0f, 1.0f);
    Enemy* enemy2 = new Enemy(100.0f, -0.7f, -0.7f, 0.3f, 0.2f, 0.0f, 1.0f, 0.0f);
    
    enemies.push_back(enemy1);
    enemies.push_back(enemy2);
    
    enemy.setX(0.7f);
    enemy.setY(0.7f);
    enemy.setWidth(0.3f);
    enemy.setHeight(0.2f);
    enemy.setColors(0.0, 0.0, 1.0);
   // Shapes enemy (soldier.getX(), soldier.getY(), 0.4, 0.4, 1.0, 0.0, 0.0);
    enemy.draw(enemy);
}