//
//  SpawningLocation.cpp
//  glutapp
//
//  Created by Sergio Rosendo on 5/1/17.
//  Copyright © 2017 Sergio Rosendo. All rights reserved.
//

#include "SpawningLocations.h"

//CONSTRUCTOR............................................
SpawningLocation :: SpawningLocation()
{
    x_coordinate = 0.0f;
    y_coordinate = 0.0f;
}

//SETTERS................................................
void SpawningLocation :: setX(float x)
{
    x_coordinate = x;
}

void SpawningLocation :: setY(float y)
{
    y_coordinate = y;
}

//GETTERS................................................
float SpawningLocation :: getX()
{
    return x_coordinate;
}

float SpawningLocation :: getY()
{
    return y_coordinate;
}
