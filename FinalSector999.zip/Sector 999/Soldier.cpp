//
//  Soldier.cpp
//  Sector 999
//
//  Created by Luis Mejia on 4/21/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#include "Soldier.h"

Soldier:: Soldier()
{
    x_coord = 0.0;
    y_coord = 0.0;
    soldierX_pos = x_coord;
    soldierY_pos = y_coord;
}

void Soldier:: draw(Master& m)
{
    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glBegin(GL_POLYGON);
    glColor3f(1.0f, 1.0f, 1.0f);
    
    //:: Top Edge
    glTexCoord2f(0.0f, 1.0f);
    glVertex2f(m.getX(), m.getY());
    
    glTexCoord2f(1.0f, 1.0f);
    glVertex2f(m.getX() + this->getWidth(), m.getY());
    
    //:: Left Edge
    glTexCoord2f(0.0f, 1.0f);
    glVertex2f(m.getX(), m.getY());
    glTexCoord2f(0.0f, 0.0f);
    glVertex2f(m.getX(), m.getY() - this->getHeight());
    
    //:: Right Edge
    glTexCoord2f(1.0f, 1.0f);
    glVertex2f(m.getX() + this -> getWidth(), m.getY());
    
    glTexCoord2f(1.0f, 0.0f);
    glVertex2f(m.getX() + this -> getWidth(), m.getY() - this -> getHeight());
    
    //:: Bottom Edge
    glTexCoord2f(1.0f, 0.0f);
    glVertex2f(m.getX() + this->getWidth(), m.getY() - this -> getHeight());
    glTexCoord2f(0.0f, 0.0f);
    glVertex2f(m.getX(), m.getY() - this -> getHeight());
    
    glEnd();
    glDisable(GL_TEXTURE_2D);
}


void Soldier:: setX(float x){ x_coord = x; }
void Soldier:: setY(float y){ y_coord = y; }
void Soldier:: setHeight(float h) { height = h; }
void Soldier:: setWidth(float w) { width = w; }
void Soldier:: setHealth(float _health) { health = _health; }

float Soldier:: getX(){ return x_coord; }
float Soldier:: getY(){ return y_coord; }
float Soldier:: getHeight() { return height;}
float Soldier:: getWidth() { return width; }
float Soldier:: getHealth() { return health; }
float Soldier:: getCenterX() { return (this->getX() + (this -> getWidth() * 0.5f) - 0.1f); }
float Soldier:: getCenterY() { return (this -> getY() - (this -> getHeight() * 0.5f) - 0.05f); }


bool Soldier:: contains(Master &m)
{
    if(m.getX() >= this->getX() && m.getX() <= (this->getX() + this->getWidth()))
    {
        if(m.getY() <= this->getY() && m.getY() >= (this->getY() - this->getHeight()))
        {
            return true;
        }
        
    }
    return false;
}



Soldier:: ~Soldier() { }
