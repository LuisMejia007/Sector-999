//
//  Functions.cpp
//  Sector 999
//
//  Created by Luis Mejia on 4/27/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#include "Functions.h"

void say_hello()
{
    cout << "Hello\n";
}

void read_write_file(string& stats)
{
    ifstream read_file ("TextFile/high_scores.txt");
    ofstream write_file ("TextFile/high_scores.txt", std::ios_base::app);
    string line;
    

   
    if(!write_file.is_open() || !read_file.is_open())
    {
        puts ("File Not Found\n");
    }

    else
    {
        for (int i = 0; i < 1; i++)
        {
            write_file <<  stats <<  "\n";
            write_file.close();
        }
    }
    
    
}