//
//  Soldier.hpp
//  Sector 999
//
//  Created by Luis Mejia on 4/21/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#ifndef Soldier_h
#define Soldier_h

#include <cstdio>
# include "Master.h"

class Soldier : public Master
{
    float x_coord;
    float y_coord;
    float center;
    float height;
    float width;
    float health;
    
public:
    Soldier();
    enum Movement { UP, RIGHT, DOWN, LEFT };        //:: Player's Movement (will be used by the keyboard special func)
    enum Arsenal {PISTOL, ASSAULT_RIFLE, MINI_GUN };  //:: Player's Weapon Selection
    float soldierX_pos = 0.0f;
    float soldierY_pos = 0.0f;
    void draw(Master& m);
    
    //:: Setters
    void setX(float x);
    void setY(float y);
    void setWidth(float w);
    void setHeight(float h);
    void setHealth(float _health);
    
    //:: Getters
    float getX();
    float getY();
    float getHeight();
    float getWidth();
    float getHealth();
    float getCenterX();
    float getCenterY(); 
    
    
    bool contains (Master& m);
    ~Soldier();
};


#endif /* Soldier_hpp */
