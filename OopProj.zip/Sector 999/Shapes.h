//
//  Shapes.hpp
//  Sector 999
//
//  Created by Luis Mejia on 4/21/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#ifndef Shapes_h
#define Shapes_h

#include <stdio.h>
# include "Master.h"


class Shapes : public Master
{
    float x_coord;
    float y_coord;
    float _r;
    float _g;
    float _b;
    float width;
    float height;
    
    
public:
  
    Shapes();
    Shapes(float x, float y, float _h, float _w, float r, float g, float b);
    
    bool shot;
    float x_inc, y_inc;
    
    void draw(Master& m);
    void draw(); 
    //:: Setters
    void setX( float x );
    void setY( float y );
    void setHeight( float h );
    void setWidth( float w );
    void setColors(float r, float g, float b);
    
    //:: Getters
    float getX();
    float getY();
    float getHeight();
    float getWidth();
    float getRed();
    float getGreen();
    float getBlue();
    
    void incX();
    void incY();
    
    void setXInc(float x);
    void setYInc(float y);
    float getXInc();
    float getYInc();
    
    ~Shapes(); 
    
};
#endif /* Shapes_hpp */
