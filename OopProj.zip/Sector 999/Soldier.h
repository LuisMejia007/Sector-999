//
//  Soldier.hpp
//  Sector 999
//
//  Created by Luis Mejia on 4/21/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#ifndef Soldier_h
#define Soldier_h

#include <cstdio>
# include "Master.h"
class Soldier : public Master
{
    float x_coord;
    float y_coord;
    
    
public:
    Soldier();
    enum Movement { UP, RIGHT, DOWN, LEFT };
    enum Arsenal {PISTOL, ASSAULT_RIFLE, MINI_GUN };
    std::vector<Master* > gun;
    void draw(Master& m);
    void setX(float x);
    void setY(float y);
    float getX();
    float getY();
    ~Soldier();
};


#endif /* Soldier_hpp */
