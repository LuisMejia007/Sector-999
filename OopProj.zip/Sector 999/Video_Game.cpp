# include "Video_Game.h"

VDEO::VDEO(const char* label, int x, int y, int w, int h): GlutApp(label, x, y, w, h){
    // Initialize state variables
    mx = 0.0;
    my = 0.0;
    shooting = false;
    VDEO::initialize();
    
}

void VDEO:: draw()
{
    // Clear the screen
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    // Set background color to black
    glClearColor(0.0, 0.0, 0.0, 1.0);
    
    // Set up the transformations stack
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
  
    glColor3d(1.0, 1.0, 0.0);
    
    for (vector<Shapes*>::iterator i = bullet_shapes.begin(); i != bullet_shapes.end(); i++) {
       
            (*i)->draw();
       
    }
    
    glBegin(GL_LINES);
    
    glVertex2f(mx - 0.05f, my);
    glVertex2f(mx + 0.05f, my);
    
    glVertex2f(mx, my - 0.05f);
    glVertex2f(mx, my + 0.05f);
    
    glEnd();
    
    
    soldier.setX(soldier.getX());
    soldier.setY(soldier.getY());
    soldier.draw(soldier);
    enemy.draw(enemy);
    
    
    
    
    
    
    if (shooting == true)
    {
        std::cout << "About To Draw: " << soldier.gun.size() << "\n";
//        //Shapes(float x, float y, float _h, float _w, float r, float g, float b);
//
//        
//     
//       
//        switch (weapon)
//        {
//            case Soldier::PISTOL:
//            
//                gat[soldier.gun.size()] -> shot = true;
//                gat[soldier.gun.size()] ->setX(bullet_x);
//                gat[soldier.gun.size()] ->setY(bullet_y);
//                gat[soldier.gun.size()] ->setWidth(0.07f);
//                gat[soldier.gun.size()] ->setHeight(0.07f);
//                gat[soldier.gun.size()] -> setColors(1.0f, 0.0f, 0.0f);
//                break;
//            
//            case Soldier::ASSAULT_RIFLE:
//                 gat[soldier.gun.size()] -> shot = true;
//                gat[soldier.gun.size()] -> setX(bullet_x);
//                gat[soldier.gun.size()] -> setY(bullet_y);
//                gat[soldier.gun.size()] -> setWidth(0.07f);
//                gat[soldier.gun.size()] -> setHeight(0.07f);
//                gat[soldier.gun.size()] -> setColors(1.0f, 0.0f, 0.0f);
//                break;
//            
//            case Soldier::MINI_GUN:
//                gat[soldier.gun.size()] -> shot = true;
//                gat[soldier.gun.size()] ->setX(bullet_x);
//                gat[soldier.gun.size()] ->setY(bullet_y);
//                gat[soldier.gun.size()] ->setWidth(0.07f);
//                gat[soldier.gun.size()] ->setHeight(0.07f);
//                gat[soldier.gun.size()] -> setColors(1.0f, 0.0f, 0.0f);
//                break;
//            default:
//                break;
//        }
//        
//
//        
//        for(int i = 0; i < gat.size(); i++)
//        {
//            if(gat[i]->shot)
//            {
//                gat[i]->draw();
//                gat[i]->incX();
//                gat[i]->incY();
//            }
//        }

    }

    
    
    
    
    glFlush();
    glutSwapBuffers();
}

void VDEO:: keyPress(unsigned char key)
{
    switch(key)
    {
        case 27:
        exit(0);
        break;
            
        case 49:
           weapon = Soldier::PISTOL;
            redraw();
            break;
        case 50:
            weapon = Soldier::ASSAULT_RIFLE;
            redraw();
            break;
        case 51:
            weapon = Soldier:: MINI_GUN;
            redraw();
            break;
            
        case 32:
            if (soldier.gun.size() == 0)  { shooting = false; }
            else
            {
                shooting = true;
                
                bullet_shapes.push_back(new Shapes(soldier.getX(), soldier.getY(), 0.1, 0.1, 0,0,1));
                
                
                switch (soldier_mov) {
                    case Soldier::UP:
                        bullet_y = soldier.getY() + 0.01f;
                        break;
                    case Soldier::LEFT:
                        bullet_x = soldier.getX() - 0.01f;
                        break;
                        
                    case Soldier::RIGHT:
                        bullet_x = soldier.getX() + 0.01f;
                        break;
                        
                    case Soldier::DOWN:
                        bullet_y = soldier.getY() - 0.01f;
                        break;
                        
                    default:
                        break;
                }
                soldier.gun.pop_back();
                std::cout << "Bullets: " << soldier.gun.size() << "\n";
            }
            redraw();
            break;
            
        case 'r':
            reload();
            break;
            
            
    }
}

void VDEO:: specialKeyPress(int key)
{
    switch(key)
    {
        case GLUT_KEY_UP:
            my += 0.03f;
            shooting = false;
            soldier_mov = Soldier:: UP;
            soldier.setY(my);
            redraw();
            break;
            
        case GLUT_KEY_DOWN:
            shooting = false;
            soldier_mov = Soldier:: DOWN;
            my -= 0.03f;
            soldier.setY(my);
            redraw();
            break;
            
        case GLUT_KEY_RIGHT:
            shooting = false;
            soldier_mov = Soldier:: RIGHT;
             mx += 0.03f;
            soldier.setX(mx);
            redraw();
            break;
            
        case GLUT_KEY_LEFT:
            shooting = false;
            soldier_mov = Soldier:: LEFT;
            mx -= 0.03f;
            soldier.setX(mx);
            redraw();
            break;
    }
}



void VDEO:: mouseDown(float x, float y){}
void VDEO:: mouseDrag(float x, float y){}



void VDEO:: idle()
{
    
    
    // Go through bullet_shapes again and remove from the list any bullets whose y value is out of screen
    

    if(soldier.gun.size() == 0)
    {
        puts("Ran out of bullets, can not shoot");
        shooting = false;
    }
    
    if(shooting)
    {
        switch(weapon)
        {   case Soldier::PISTOL:   bullet_speed = 0.02f; break;
            case Soldier::ASSAULT_RIFLE: bullet_speed = 0.03f; break;
            case Soldier::MINI_GUN: bullet_speed = 0.05f; break;
        }
        
        switch (soldier_mov) {
            case Soldier::UP:
                bullet_y += bullet_speed;
                bullet_x = soldier.getX();
                 redraw();
                break;
                
            case Soldier:: LEFT:
                bullet_x -= bullet_speed;
                bullet_y = soldier.getY();
                 redraw();
                break;
                
            case Soldier:: RIGHT:
                bullet_x += bullet_speed;
       
                bullet_y = soldier.getY();
                 redraw();
                break;
                
            case Soldier:: DOWN:
                bullet_y -= bullet_speed;
                bullet_x = soldier.getX();
                redraw();
                break;
                
            default:
                break;
        }
        
        if(bullet_shapes.size() != 0)
        {
            for (vector<Shapes*>::iterator i = bullet_shapes.begin(); i != bullet_shapes.end(); i++)
            {
             
                switch(soldier_mov)
                {
                    case Soldier::UP:
                        (*i)->setY((*i)->getY() + bullet_y);
                        break;
                    case Soldier:: DOWN:
                        (*i)->setY((*i)->getY() + bullet_y);
                        break;
                    case Soldier:: RIGHT:
                        (*i)->setX((*i)->getX() + bullet_x);
                        break;
                    case Soldier:: LEFT:
                        (*i)->setX((*i)->getX() + bullet_x);
                        break;
                }
            }
        }
        
        for (vector<Shapes*>::iterator i = bullet_shapes.begin(); i != bullet_shapes.end(); i++)
        {
//            if ((*i)->getY() > 1.1 && (*i)->shot)
//            {
                bullet_shapes.erase(i);
               // delete (*i);
//            }
            
        }

    }
    redraw();
}

void VDEO:: reload()
{
    
    if(soldier.gun.size() == 0)
    {
        soldier.gun.resize(10);
        std::cout << "Bullets After Reload: " << soldier.gun.size() << "\n";
    }
    
}

void VDEO:: initialize()
{
  //:: Soldier Initialization
    weapon = Soldier::ASSAULT_RIFLE;
    soldier.gun.resize(10);
    
    for(int i = 0; i < 10; i++)
    {
        Shapes* n = new Shapes;
        gat.push_back(n);
    }
    
    soldier.setY(0.0f);
    soldier.setX(0.1f);
    soldier.draw(soldier);
    
    enemy.setX(0.7f);
    enemy.setY(0.7f);
    enemy.draw(enemy);
}