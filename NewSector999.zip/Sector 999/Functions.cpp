//
//  Functions.cpp
//  Sector 999
//
//  Created by Luis Mejia on 4/27/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#include "Functions.h"

void say_hello()
{
    std::cout << "Hello\n";
}


void check_shooting(int ammo, bool& shooting)
{
    if(ammo == 0)
    {
        puts("Ran out of bullets, can not shoot");
        shooting = false;
    }
    
}

void check_weapon(bool& shooting, Soldier::Arsenal& weapon, int bullet_speed)
{
    
    if(shooting)
    {
        switch(weapon)
        {   case Soldier::PISTOL:   bullet_speed = 0.02f; break;
            case Soldier::ASSAULT_RIFLE: bullet_speed = 0.03f; break;
            case Soldier::MINI_GUN: bullet_speed = 0.05f; break;
        }
    }
    
}

void check_bulletCollisions(vector<Shapes* >& bullets, vector<Enemy* >& enemies, Shapes& bulletObj, Enemy& enemy, Soldier::Arsenal& weapon, int  bullet_speed)
{
    for (vector<Shapes*>::iterator i = bullets.begin(); i != bullets.end(); i++)
    {
        //:: Continuosly moving the bullets that have been shot. Check Shapes.h for more details on the 'move_bullet' function
        bulletObj.move_bullet((*i), bullet_speed);
        
        //::Check if Bullet Hit Enemy
        if( enemy.contains(*(*i)))
        {
            enemy.health_damage(weapon);
        }
        
        //std::cout << "Bullet Shape Size: " << bullet_shapes.size() << "\n";
        
        if ((*i)->getY() > 1.0)
        {
            delete *i;
            bullets.erase(i);
            if(i == bullets.end())
            {
                break;
            }
        }
        
        for(vector<Enemy* >:: iterator j = enemies.begin(); j != enemies.end(); j++)
        {
            if((*j)->contains(*(*i)))
            {
                if((*j)->getHealth() <= 0.0f)
                {
                    delete (*j);
                    enemies.erase(j);
                    if(j == enemies.end()) {break;}
                }
                (*j)->health_damage(weapon);
            }
        }
    }
}