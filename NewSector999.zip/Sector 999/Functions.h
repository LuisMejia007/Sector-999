//
//  Functions.hpp
//  Sector 999
//
//  Created by Luis Mejia on 4/27/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#ifndef Functions_hpp
#define Functions_hpp

#include <stdio.h>
# include "Soldier.h"
# include "Shapes.h"
# include "Enemy.h"
# include "Video_Game.h"
# include <iostream> 
using std::vector;

void say_hello();
void check_shooting(int ammo, bool& shooting);
void check_weapon(bool& shooting, Soldier::Arsenal& weapon, int bullet_speed);
void check_bulletCollisions(vector<Shapes* >& bullets, vector<Enemy* >& enemies, Shapes& bulletObj,Enemy& enemy, Soldier::Arsenal& weapon, int bullet_speed);

#endif /* Functions_hpp */
