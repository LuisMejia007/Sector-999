//
//  Functions.hpp
//  Sector 999
//
//  Created by Luis Mejia on 4/27/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#ifndef Functions_hpp
#define Functions_hpp

#include <stdio.h>
# include "Soldier.h"
# include "Shapes.h"
# include "Enemy.h"
# include "Video_Game.h"
# include <iostream> 
# include <fstream>
# include <cstring>
using std::vector;
using std:: cin;
using std:: cout; 
using std:: string;
using std:: ifstream;
using std:: ofstream;

void say_hello();
void read_write_file(string& stats);

#endif /* Functions_hpp */
