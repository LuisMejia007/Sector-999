# include "Video_Game.h"
# include <iostream>

VDEO::VDEO(const char* label, int x, int y, int w, int h): GlutApp(label, x, y, w, h)
{
    
    //loading the textures that will be used
#if defined WIN32
    galaxy = loadTexture("..\\galaxy.bmp");
    sector = loadTexture("..\\sector.bmp");
    opposing = loadTexture("..\\wall.bmp");
    p1 = loadTexture("..\\Textures/meta.bmp");
    alien = loadTexture("..\\Textures/doom.bmp")
    sector = loadTexture("..\\Textures/SECTOR999.bmp");
    sector_999 = loadTexture("..\\Textures/999.bmp");
    sector_invert = loadTexture("..\\Textures/SECTOR999Twisted.bmp");
    
#else
    galaxy = loadTexture("Textures/galaxy.bmp");
    sector = loadTexture("Textures/sector.bmp");
    opposing = loadTexture("Textures/wall.bmp");
    p1 = loadTexture("Textures/meta.bmp");
    alien = loadTexture("Textures/doom.bmp");
    sector = loadTexture("Textures/SECTOR999.bmp");
    sector_999 = loadTexture("Textures/999.bmp");
    sector_invert = loadTexture("Textures/SECTOR999Weird.bmp");
#endif
    
    // Initialize state variables
    mx = 0.0;
    my = 0.0;
    shooting = false;
    
    if (!start_game) { start_game_menu(); }
    
    VDEO::initialize();
    VDEO::initializeSpawningLocations(locations);
    start_time = time(0);
    time(&startTime);
    updateTime(ns, seconds, minutes, hours);

}

GLuint VDEO:: loadTexture(const char *filename)
{
    GLuint tex_id;
    glClearColor (0.0, 0.0, 0.0, 0.0);
    glShadeModel(GL_FLAT);
    glEnable(GL_DEPTH_TEST);
    
    RgbImage theTexMap( filename );
    
    // Pixel alignment: each row is word aligned (aligned to a 4 byte boundary)
    //    Therefore, no need to call glPixelStore( GL_UNPACK_ALIGNMENT, ... );
    
    
    glGenTextures( 1, &tex_id );
    glBindTexture( GL_TEXTURE_2D, tex_id );
    
    
    gluBuild2DMipmaps(GL_TEXTURE_2D, 3, theTexMap.GetNumCols(), theTexMap.GetNumRows(),
                      GL_RGB, GL_UNSIGNED_BYTE, theTexMap.ImageData() );
    
    return tex_id;
}

void VDEO:: draw()
{
    if(game_over == false && start_game == true)
    {
          // Clear the screen
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    // Set background color to black
    glClearColor(1.0, 1.0, 1.0, 1.0);
    
    // Set up the transformations stack
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    ammo_display();
    display_gun();
    display_time();
    death_score();
    
       
    //:: BLINK |  Indicate Low Player Health --
    if (soldier.getHealth() <= 50)
    {
        health_bar->setColors(red, 0.0, 0.0);
    }
    //:: --------------------------------------

    health_bar -> draw();
    
    for (vector<Shapes*>::iterator i = bullet_shapes.begin(); i != bullet_shapes.end(); i++)
    {
        //:: If Bullet hasn't "pierced" within enemy
        if((*i)->_draw)
        {
            (*i)->draw();
        }
        
    }
    
    for(vector<Enemy* >::iterator i = enemies.begin(); i != enemies.end(); i++)
    {
        glBindTexture(GL_TEXTURE_2D, alien);
        (*i)->draw();
    }
    
    
    soldier.setX(soldier.getX());
    soldier.setY(soldier.getY());
    glBindTexture(GL_TEXTURE_2D, p1);
    soldier.draw(soldier);
    enemy.draw(enemy);
    
    glBegin(GL_LINES);
    
    glVertex2f(mx - 0.05f, my);
    glVertex2f(mx + 0.05f, my);
    glVertex2f(mx, my - 0.05f);
    glVertex2f(mx, my + 0.05f);
    glEnd();
    
    glDisable(GL_TEXTURE_2D);
    glFlush();
    glutSwapBuffers();
        
    }
  
}

void VDEO:: keyPress(unsigned char key)
{
    switch(key)
    {
        case 27:
        exit(0);
        break;
            
        case 32:
            start_game = true;
            redraw();
            break;
            
        case 49:    //:: Case 49 is keypad number 1
           weapon = Soldier::PISTOL;
            ammo = 25;
            redraw();
            break;
            
        case 50:    //:: Case 50 is keypad number 2
            weapon = Soldier::ASSAULT_RIFLE;
            ammo = 99;
            redraw();
            break;
            
        case 51:     //:: Case 51 is keypad number 3
            weapon = Soldier:: MINI_GUN;
            ammo = 50;
            redraw();
            break;
        
        case 'p':
            soldier.setHealth(100.0f);
            health_bar -> setWidth(0.92f);
            redraw();
            break;
            
        case 'r':
            reload();
            break;
            
        //:: Soldier Movement
            case 'w':   //:: Moving Up
            soldierY_pos += 0.05f;
            soldier_mov = Soldier:: UP;
            soldier.setY(soldierY_pos);
            redraw();
            break;
            
            case 'd': //:: Moving Right
            soldier_mov = Soldier:: RIGHT;
            soldierX_pos += 0.05f;
            soldier.setX(soldierX_pos);
            redraw();
            break;
        
            case 's': //:: Moving Down
            soldier_mov = Soldier:: DOWN;
            soldierY_pos -= 0.05f;
            soldier.setY(soldierY_pos);
            redraw();
            break;
            
            case 'a': //:: Moving Left
            soldier_mov = Soldier:: LEFT;
            soldierX_pos -= 0.05f;
            soldier.setX(soldierX_pos);
            redraw();
            break;
            
    }
}

void VDEO:: specialKeyPress(int key){}

void VDEO:: mouseDown(float x, float y){
    
    mx = x; my = y;
    if( ammo == 0 ) { shooting = false; }
    else
    {
        //:: Create a new "bullet" which is just a pointer to the Shapes class
        //:: By Default it will have the X and Y position of the soldier
        shooting = true;
        Shapes* bullet = new Shapes();
        bullet -> setX(soldier.getCenterX());
        bullet -> setY(soldier.getCenterY());
        switch (weapon) {
            case Soldier::PISTOL:
                bullet -> setColors(1.0, 0.0, 1.0);
                bullet -> setWidth(0.04f);
                bullet -> setHeight(0.04f);
                break;
                
            case Soldier::ASSAULT_RIFLE:
                bullet -> setColors(0.0f, 1.0f, 1.0f);
                bullet -> setWidth(0.03f);
                bullet -> setHeight(0.03f);
                break;
            case Soldier:: MINI_GUN:
                bullet -> setColors(1.0f, 0.0f, 1.0f);
                bullet -> setWidth(0.02f);
                bullet -> setHeight(0.03f);
                break;
            default:
                break;
        }
        
        bullet -> trajectoryX = mx;
        bullet -> trajectoryY = my;
        bullet_shapes.push_back(bullet);
        ammo--;
    }
    
    redraw();

}
void VDEO:: mouseDrag(float x, float y)
{
    mx = x; my = y;
    if( ammo == 0 ) { shooting = false; }
    else
    {
        //:: Create a new "bullet" which is just a pointer to the Shapes class
        //:: By Default it will have the X and Y position of the soldier
        shooting = true;
        Shapes* bullet = new Shapes();
        bullet -> setX(soldier.getCenterX());
        bullet -> setY(soldier.getCenterY());
        if (weapon == Soldier::MINI_GUN)
        {
            bullet -> setColors(0.0f, 0.5f, 1.0f);
            bullet -> setWidth(0.02f);
            bullet -> setHeight(0.03f);
            bullet -> trajectoryX = mx;
            bullet -> trajectoryY = my;
            bullet_shapes.push_back(bullet);
            ammo--;
        }
        
    }
    
    redraw();
}



void VDEO:: idle()
{
    if (game_over == false && start_game == true)
    {
    //SPAWN NEW ENEMY?...........................................
    time(&endTime);
    timeDifference = difftime(endTime, startTime);


    updateTime(ns, seconds, minutes, hours);
    if(ammo == 0){ shooting = false; }
   
    check_gun_type();
    bullet_update();
    enemy.update_health(enemies, bullet_shapes, weapon, enemy_killed_counter);
    player_health_update();
    

    if(timeDifference == 1)
    {
        //SPAWN NEW ENEMY
        Enemy *enemy = new Enemy;
        
        //INITIALIZE ENEMY
        enemy_initialize(enemy);
        
        //PUSH ENEMY INTO ENEMIES VECTOR
        enemies.push_back(enemy);
        
        //COUNT 5 SECONDS AGAIN
        time(&startTime);
        
        //DISPLAY
       // redraw();
    }

    enemy_controller.enemy_AI(enemies, soldier);
    
    redraw();
    }
    
    else if (game_over)
    {
        game_over_menu();
    }
}

void VDEO:: reload()
{
    if(ammo == 0)
    {
        switch(weapon)
        {
            case Soldier::PISTOL:
                ammo = 25;
                break;
            case Soldier:: ASSAULT_RIFLE:
                ammo = 99;
                break;
            case Soldier:: MINI_GUN:
                ammo = 50;
                break;
        }
    }
    
}

void VDEO:: enemy_initialize(Enemy *&enemy)
{
    //RANDOMLY SELECT ENEMY TYPE
    switch(rand() % 3)
    {
        case 0:
            enemy->setHealth(100);
            enemy -> setColors(1.0f, 1.0f, 1.0f);   //:: Must Set To White for Textures to work
            enemy -> setX(0.4f);
            enemy -> setY(0.2f);
            enemy -> setWidth(0.5f);
            enemy -> setHeight(0.5f);
            enemy->setSpeed(0.01f);
            enemy->setBlastRadius(0.045f);
            break;
        case 1:
            enemy->setHealth(5);
              enemy -> setColors(1.0f, 1.0f, 1.0f); //:: Must Set To White for Textures to work
            enemy -> setX(0.4f);
            enemy -> setY(0.2f);
            enemy -> setWidth(0.2f);
            enemy -> setHeight(0.2f);
            enemy->setSpeed(0.02f);
            enemy->setBlastRadius(0.045f);
            
            break;
        case 2:
            enemy->setHealth(10);
             enemy -> setColors(1.0f, 1.0f, 1.0f);  //:: Must Set To White for Textures to work
            enemy -> setX(0.4f);
            enemy -> setY(0.2f);
            enemy -> setWidth(0.1f);
            enemy -> setHeight(0.1f);
            enemy->setSpeed(0.007f);
            enemy->setBlastRadius(0.095f);
            break;
        case 3:
            enemy->setHealth(30);
            enemy -> setColors(1.0f, 1.0f, 1.0f);  //:: Must Set To White for Textures to work
            enemy -> setX(0.4f);
            enemy -> setY(0.2f);
            enemy -> setWidth(0.3f);
            enemy -> setHeight(0.3f);
            enemy -> setSpeed(0.02f);
            enemy->setBlastRadius(0.095f);
            break;
        default:
            timeDifference = 1;
            break;
            
    };
    
    //RANDOMLY SELECT SPAWNING LOCATION
    SpawningLocation location = locations[rand() % 8];
    enemy->setX(location.getX());
    enemy->setY(location.getY());
}


//INITIALIZE SPAWNING HOTSPOTS............................................
void VDEO :: initializeSpawningLocations(SpawningLocation (&locations)[8])
{
    
    //FIRST LOCATION
    locations[0].setX(0.0f);
    locations[0].setY(1.0f);
    
    //SECOND LOCATION
    locations[1].setX(1.0f);
    locations[1].setY(0.0f);
    
    //THIRD LOCATION
    locations[2].setX(0.0f);
    locations[2].setY(-1.0f);
    
    //FOURTH LOCATION
    locations[3].setX(-1.0f);
    locations[3].setY(0.0f);
    
    //FIFTH LOCATION
    locations[4].setX(-1.0f);
    locations[4].setY(1.0f);
    
    //SIXTH LOCATION
    locations[5].setX(1.0f);
    locations[5].setY(1.0f);
    
    //SEVENTH LOCATION
    locations[6].setX(1.0f);
    locations[6].setY(-1.0f);
    
    //EIGHTH LOCATION
    locations[7].setX(-1.0f);
    locations[7].setY(-1.0f);
    
    
}

void VDEO:: updateTime(::nanoseconds &nano, ::seconds &sec, ::minutes &min, ::hours &hrs)
{
    current_time = difftime(time(0), start_time);
    std::chrono::seconds s (current_time);
    ns = std::chrono::duration_cast<std::chrono::nanoseconds> (s);
    seconds = std::chrono::duration_cast<std::chrono::seconds>(ns);
    minutes = std::chrono::duration_cast<std::chrono::minutes>(seconds);
    hours = std::chrono::duration_cast<std::chrono::hours>(minutes);

}

void VDEO:: display_time()
{
    glColor3f(0.0f, 0.0f,0.0f);
    glRasterPos2f(-0.09f, 0.85f);
    
    string time = to_string(hours.count()) + " :: " + to_string(minutes.count() % 60) + " :: " + to_string(seconds.count() % 60);
    
    for(int i = 0; i < time.length(); i++)
    {
        glutBitmapCharacter(GLUT_BITMAP_9_BY_15, time[i]);
    }
}

void VDEO:: check_gun_type()
{
    //:: Track Soldier's Gun Type | Specify Bullet Speed Respective of Gun Type --
    if(shooting)
    {
        switch(weapon)
        {   case Soldier::PISTOL:   bullet_speed = 0.02f; break;
            case Soldier::ASSAULT_RIFLE: bullet_speed = 0.03f; break;
            case Soldier::MINI_GUN: bullet_speed = 0.05f; break;
        }
    }
}

void VDEO:: display_gun()
{
    
    //:: Gun Display ----------------------------

    switch (weapon) {
        case Soldier::PISTOL:
            glColor3f(1.0f, 0.0f, 1.0f);
            glRasterPos2f(-0.75f, 0.85f);
            selected_weapon = "PISTOL";
            for(int i = 0; i < selected_weapon.length(); i++)
            {
                glutBitmapCharacter(GLUT_BITMAP_9_BY_15, selected_weapon[i]);
            }
            break;
            
        case Soldier::ASSAULT_RIFLE:
            glColor3f(1.0f, 0.0f, 0.0f);
            glRasterPos2f(-0.75f, 0.85f);
            selected_weapon = "ASSAULT RIFLE";
            for(int i = 0; i < selected_weapon.length(); i++)
            {
                glutBitmapCharacter(GLUT_BITMAP_9_BY_15, selected_weapon[i]);
            }
            break;
            
        case Soldier::MINI_GUN:
            glColor3f(0.0f, 0.0f, 1.0f);
            glRasterPos2f(-0.75f, 0.85f);
            selected_weapon = "MINI GUN";
            for(int i = 0; i < selected_weapon.length(); i++)
            {
                glutBitmapCharacter(GLUT_BITMAP_9_BY_15, selected_weapon[i]);
            }
            break;
            
        default:
            break;
    }
    //:: ---------------------------------------------------------------------
}

void VDEO:: ammo_display()
{
    glColor3f(1.0, 0.0, 0.0);
    glRasterPos2f(-0.85,-0.85);
    string ammo_counter = to_string(ammo);
    for(int i = 0; i < ammo_counter.length(); i++)
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, ammo_counter[i]);
    }
}

void VDEO:: bullet_update()
{
    for (vector<Shapes*>::iterator i = bullet_shapes.begin(); i != bullet_shapes.end(); i++)
    {
        
        bulletObj.moveTheBullet((*i), bullet_speed, soldier); //:: Bullet Update. Check Shapes.h (moveTheBullet func)
        //::Check if Bullet Hit Enemy
        if( enemy.contains(*(*i)))
        {
            enemy.health_damage(weapon);
        }
        //:: MEMORY DE-ALLOCATION | Delete bullets if they pass screen boundary ---------------------
        if ((*i)->getY() > 1.0 || (*i)->getY() < -1.0 || (*i)->getX() > 1.0 || (*i)->getX() < -1.0)
        {
            delete *i;
            bullet_shapes.erase(i);
            if(i == bullet_shapes.end()){ break; }
        }
        
    }
}

void VDEO:: player_health_update()
{
    red = static_cast< float > (rand()) / (static_cast <float> (RAND_MAX / 1.0));   //:: When Player Health Low
    //:: Soldier Health Updates -----------------------------------------------------
    
    if (soldier.getHealth() <= 0.0f)
    {
        game_over = true;
    }
    
    for (vector <Enemy* >::iterator e = enemies.begin(); e != enemies.end(); e++)
    {
        if (soldier.contains(*(*e)))
        {
            soldier.setHealth(soldier.getHealth() - 0.04040f);
            health_bar -> setWidth(health_bar->getWidth() - std::abs(soldier.getHealth() * 0.00000807));
        }
    }
}

void VDEO:: death_score()
{
    //:: Enemy Death Count -------------------------------------------
    glColor3f(0.7f, 0.2f, 0.1f);
    glRasterPos2f(0.45f, 0.85f);
    string death_count = "DEATH_COUNT:: " + to_string(enemy_killed_counter);
    for(int i = 0; i < death_count.length(); i++)
    {
        glutBitmapCharacter(GLUT_BITMAP_9_BY_15, death_count[i]);
    }
    //:: --------------------------------------------------------
}

void VDEO:: initialize()
{
    
    srand(time(NULL));  //:: Set Random Seed
    
  //:: Soldier Initialization
    weapon = Soldier::ASSAULT_RIFLE;
    ammo = 99;

    soldier.setY(soldierY_pos);
    soldier.setX(soldierX_pos);
    soldier.setWidth(0.3f);
    soldier.setHeight(0.3f);
    soldier.setHealth(100.0f);
    glBindTexture(GL_TEXTURE_2D, p1);
    soldier.draw(soldier);
    
    VDEO::initializeSpawningLocations(locations);
    Enemy* enemy1 = new Enemy(50.0f, 0.7f, 0.7f,0.1f, 0.1f, 1.0f, 1.0f, 1.0f);
    Enemy* enemy2 = new Enemy(50.0f, -0.7f, -0.7f, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f);
    Enemy* enemy3 = new Enemy (100.0f, 0.2f, 0.2f, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f);
    Enemy* enemy4 = new Enemy (100.0f, -0.2f, -0.2f,0.1f, 0.1f, 1.0f, 1.0f, 1.0f);
    
    enemy1 -> setSpeed(0.01f);
    enemy2 -> setSpeed(0.01f);
    enemy3 -> setSpeed(0.01f);
    enemy4 -> setSpeed(0.01f);
    
    enemies.push_back(enemy1);
    enemies.push_back(enemy2);
    enemies.push_back(enemy3);
    enemies.push_back(enemy4);

}

void VDEO:: start_game_menu()
{

    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearColor(1.0, 1.0, 1.0, 1.0);
    
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    
    glColor3f(1.0, 0.0, 0.0);
    glRasterPos2f(-0.15,-0.8f);
    string game_start = "|SECTOR 999|";
 
    for(int i = 0; i < game_start.length(); i++)
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, game_start[i]);
    }
    
    
    glColor3f(1.0, 0.0, 0.0);
    glRasterPos2f(-0.25,-0.88f);
    string command = "Press Space Bar To Play.";
    
    for(int i = 0; i < command.length(); i++)
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, command[i]);
    }
    
    glBindTexture(GL_TEXTURE_2D, sector);
    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glBegin(GL_POLYGON);
    glColor3f(1.0f, 1.0f, 1.0f);
    
    //:: Top Edge
    glTexCoord2f(0.0f, 1.0f);
    glVertex2f(-1.0f, 0.5f);
    glTexCoord2f(1.0f, 1.0f);
    glVertex2f( 0.2f, 0.5f);
    //::Left Edge
    glTexCoord2f(0.0f, 1.0f);
    glVertex2f(-1.0f, 0.5f);
    glTexCoord2f(0.0f, 0.0f);
    glVertex2f(-1.0f, -0.5f);
    //:: Right Edge
    glTexCoord2f(1.0f, 1.0f);
    glVertex2f(0.2f, 0.5f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex2f(0.2f,-0.5f);
    //::Bottom Edge
    glTexCoord2f(0.0f, 0.0f);
    glVertex2f(-1.0f, -0.5f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex2f(0.2f, -0.5f);
    glEnd();
    glDisable(GL_TEXTURE_2D);
    
    
    
    
    glBindTexture(GL_TEXTURE_2D, sector_999);
    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glBegin(GL_POLYGON);
    glColor3f(1.0f, 1.0f, 1.0f);
    
    //:: Top Edge
    glTexCoord2f(0.0f, 1.0f);
    glVertex2f(0.0f, 0.5f);
    glTexCoord2f(1.0f, 1.0f);
    glVertex2f( 1.0f, 0.5f);
    //::Left Edge
    glTexCoord2f(0.0f, 1.0f);
    glVertex2f(0.0f, 0.5f);
    glTexCoord2f(0.0f, 0.0f);
    glVertex2f(0.0f, -0.5f);
    //:: Right Edge
    glTexCoord2f(1.0f, 1.0f);
    glVertex2f(1.0f, 0.5f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex2f(1.0f,-0.5f);
    //::Bottom Edge
    glTexCoord2f(0.0f, 0.0f);
    glVertex2f(0.0f, -0.5f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex2f(1.0f, -0.5f);
    glEnd();
    glDisable(GL_TEXTURE_2D);
    
    
    
 
    glFlush();
    glutSwapBuffers();
}

void VDEO:: game_over_menu()
{
    
    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearColor(1.0, 1.0, 1.0, 1.0);
    
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    
    glBindTexture(GL_TEXTURE_2D, sector_invert);
    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glBegin(GL_POLYGON);
    glColor3f(1.0f, 1.0f, 1.0f);
    
    //:: Top Edge
    glTexCoord2f(0.0f, 1.0f);
    glVertex2f(-1.0f, 0.5f);
    glTexCoord2f(1.0f, 1.0f);
    glVertex2f( 1.0f, 0.5f);
    //::Left Edge
    glTexCoord2f(0.0f, 1.0f);
    glVertex2f(-1.0f, 0.5f);
    glTexCoord2f(0.0f, 0.0f);
    glVertex2f(-1.0f, -0.5f);
    //:: Right Edge
    glTexCoord2f(1.0f, 1.0f);
    glVertex2f(1.0f, 0.5f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex2f(1.0f,-0.5f);
    //::Bottom Edge
    glTexCoord2f(0.0f, 0.0f);
    glVertex2f(-1.0f, -0.5f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex2f(1.0f, -0.5f);
    glEnd();
    glDisable(GL_TEXTURE_2D);
    
    

    glColor3f(1.0, 0.0, 0.0);
    glRasterPos2f(-0.65, -0.7f);
    string game_end = "| GAME OVER | TIME ::" + to_string(hours.count()) + " :: " + to_string(minutes.count() % 60) + " :: " + to_string(seconds.count() % 60) + " | SCORE :: " + to_string(enemy_killed_counter);
    for(int i = 0; i < game_end.length(); i++)
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, game_end[i]);
    }
    
    read_write_file(game_end);

    
    glFlush();
    glutSwapBuffers();
}