//
//  Enemy.cpp
//  Sector 999
//
//  Created by Luis Mejia on 4/25/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

#include "Enemy.h"

Enemy:: Enemy()
{
    health = 100.0f;
    _enemy = Standard;
}

Enemy:: Enemy(float _health, float x, float y, float w, float h, float r, float g, float b)
    :health(_health), x_coord(x), y_coord(y), width(w), height(h),red(r), green(g), blue(b) {}

void Enemy:: draw(Master& m)
{
    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glBegin(GL_POLYGON);
    
    glColor3f(getRed(), getGreen(), getBlue());
    
    //:: Top Edge
    glTexCoord2f(0.0f, 1.0f);
    glVertex2f(getX(), getY());
    glTexCoord2f(1.0f, 1.0f);
    glVertex2f(getX() + getWidth(), getY());
    
    //::Left Edge
    glTexCoord2f(0.0f, 1.0f);
    glVertex2f(getX(), getY());
    glTexCoord2f(0.0f, 0.0f);
    glVertex2f(getX(), getY() - getHeight());
    
    //:: Right Edge
    glTexCoord2f(1.0f, 1.0f);
    glVertex2f(getX() + getWidth(), getY());
    glTexCoord2f(1.0f, 0.0f);
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    //::Bottom Edge
    glTexCoord2f(0.0f, 0.0f);
    glVertex2f(getX(), getY() - getHeight());
    glTexCoord2f(1.0f, 0.0f);
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    glEnd();
    glDisable(GL_TEXTURE_2D);
    
}

void Enemy:: draw()
{
    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glBegin(GL_POLYGON);
    
    glColor3f(getRed(), getGreen(), getBlue());
    
    //:: Top Edge
    glTexCoord2f(0.0f, 1.0f);
    glVertex2f(getX(), getY());
    glTexCoord2f(1.0f, 1.0f);
    glVertex2f(getX() + getWidth(), getY());
    
    //::Left Edge
    glTexCoord2f(0.0f, 1.0f);
    glVertex2f(getX(), getY());
    glTexCoord2f(0.0f, 0.0f);
    glVertex2f(getX(), getY() - getHeight());
    
    //:: Right Edge
    glTexCoord2f(1.0f, 1.0f);
    glVertex2f(getX() + getWidth(), getY());
    glTexCoord2f(1.0f, 0.0f);
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    //::Bottom Edge
    glTexCoord2f(0.0f, 0.0f);
    glVertex2f(getX(), getY() - getHeight());
    glTexCoord2f(1.0f, 0.0f);
    glVertex2f(getX() + getWidth(), getY() - getHeight());
    
    glEnd();
    glDisable(GL_TEXTURE_2D);
    
}

//:: Setters
void Enemy:: setX( float x ){ x_coord = x; }
void Enemy:: setY( float y ){ y_coord = y; }
void Enemy:: setHeight( float h ) { height = h; }
void Enemy:: setWidth( float w ){ width = w; }
void Enemy:: setColors(float r, float g, float b) {red = r; green= g; blue = b; glColor3f(red, green, blue); }
void Enemy:: setHealth(float h) { health = h; }
void Enemy:: setSpeed(float speed) { enemy_speed = speed; }
void Enemy:: setBlastRadius(float br) { blastRadius = br; }

//:: Getters
float Enemy:: getX() { return x_coord; }
float Enemy:: getY() { return y_coord; }
float Enemy:: getHeight() { return height; }
float Enemy:: getWidth() { return width; }
float Enemy:: getRed() { return red; }
float Enemy:: getGreen() { return green; }
float Enemy:: getBlue() { return blue; }
float Enemy:: getHealth(){ return health; }
float Enemy:: getSpeed() { return enemy_speed; }
float Enemy:: getBlastRadius() { return blastRadius; }




void Enemy:: health_damage(enum Soldier::Arsenal& gun)
{
    switch (gun) {
        case Soldier::PISTOL:
            health -= 0.25;
            break;
            
        case Soldier::ASSAULT_RIFLE:
            health -= 0.50;
            break;
        case Soldier::MINI_GUN:
            health -= 0.65;
            break;
            
        default:
            break;
    }
}

bool Enemy:: contains(Master& m)
{
    if(m.getX() >= this->getX() && m.getX() <= (this->getX() + this->getWidth()))
    {
        if(m.getY() <= this->getY() && m.getY() >= (this->getY() - this->getHeight()))
        {
            return true;
        }
        
    }
    return false;
}

void Enemy:: enemy_AI(std::vector<Enemy *> &enemies, Soldier &soldier)
{
    for(int i = 0; i < enemies.size(); ++i)
    {
        float x_distance = soldier.getX() - enemies[i]->getX();
        float y_distance = soldier.getY() - enemies[i]->getY();
        float distance = sqrt(x_distance * x_distance + y_distance * y_distance);
        
        if (distance > 0)
        {
            
            if(distance > 0.1)
            {
                enemies[i]->setX( enemies[i]->getX() + (x_distance * enemies[i]->getSpeed()));
                enemies[i]->setY( enemies[i]->getY() + (y_distance * enemies[i]->getSpeed()));
            }
            else
            {
                enemies[i]->setX( enemies[i]->getX() + (x_distance * enemies[i]->getSpeed() * 7));
                enemies[i]->setY( enemies[i]->getY() + (y_distance * enemies[i]->getSpeed() * 7));
            }
            
        }
        
    }
}


void Enemy:: update_health(std::vector<Enemy *> &enemies, std::vector<Shapes *> &bullets, enum Soldier::Arsenal& weapon,  int& death_count)
{
    //:: Enemy Health Updates ---------------------------------------------------
    for(std::vector<Shapes* >:: iterator i = bullets.begin(); i != bullets.end(); i++)
    {
        for(std::vector<Enemy* >:: iterator j = enemies.begin(); j != enemies.end(); j++)
        {
            if((*j)->contains(*(*i)))
            {
                (*i) -> _draw = false;          //:: When Bullet hits enemy do not draw the bullet
                
                if((*j)->getHealth() <= 0.0f)
                {
                    delete (*j);              //:: MEMORY DE-ALLOCATION | If Enemy's health is lower than 0, delete
                    enemies.erase(j);
                    death_count++;
                    if(j == enemies.end()) { break; }
                }
                (*j)->health_damage(weapon);
            }
        }
        
    }
  
    //:: -------------------------------------------------------------------------
}


Enemy:: ~Enemy() {}

